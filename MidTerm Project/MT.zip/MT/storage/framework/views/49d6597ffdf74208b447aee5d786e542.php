
<?php $__env->startSection('content'); ?>

    <div class="container mt-5 card p-3 shadow-sm">
        <div class="d-flex justify-content-between align-items-center"> <a href="<?php echo e(url()->previous()); ?>"
                class="btn btn-secondary my-4 d-inline-block">←
                Back</a>
            <div style="height: 50px; width: auto;"
                class="bg-success p-2 d-flex justify-content-center align-items-center rounded  text-white">
                Task from: <?php echo e($opportunity->customer_name); ?>

            </div>
        </div>
        <div class="d-flex">
            <h2>Opportunity/Task</h2>
            <?php if($opportunity->status == "pending" || $opportunity->status == "done"): ?>
                <div class="bg-success p-2 d-flex justify-content-center align-items-center rounded ml-3 text-white">
                    <?php echo e(strtoupper($opportunity->status)); ?>

                </div>
            <?php endif; ?>
            <?php if($opportunity->status != "pending"): ?>
                <div class="bg-success p-2 d-flex justify-content-center align-items-center rounded ml-3 text-white">
                    Task taken by: <?php echo e(strtoupper($opportunity->staff_name)); ?>

                </div>
                <div
                    class="<?php echo e($opportunity->remark == 'done' ? 'bg-secondary' : ($opportunity->remark == 'good' ? 'bg-success' : ($opportunity->remark == 'bad' ? 'bg-danger' : 'bg-warning'))); ?> p-2 d-flex justify-content-center align-items-center rounded ml-3 text-white">
                    <?php if($opportunity->remark == "done"): ?>
                        Not Yet Rated
                    <?php elseif($opportunity->remark == "good"): ?>
                        Rated as: Good
                    <?php elseif($opportunity->remark == "bad"): ?>
                        Rated as: Bad
                    <?php elseif($opportunity->remark == "ongoing"): ?>
                        On Going
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </div>

        <div class="my-3">
            <label for="title" class="form-label">
                <h5>Title</h5>
            </label>
            <input type="text" class="form-control" id="title" name="title" readonly value="<?php echo e($opportunity->title); ?>">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">
                <h5>Description</h5>
            </label>
            <textarea class="form-control" id="description" name="description" rows="3"
                readonly> <?php echo e($opportunity->description); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="amount" class="form-label">
                <h5>Amount</h5>
            </label>
            <input min="1" type="number" class="form-control" id="amount" name="amount" readonly
                value="<?php echo e($opportunity->amount); ?>">
        </div>

        <?php if($opportunity->status != "pending" && $opportunity->comment != null): ?>
            <div class="mb-3">
                <label for="description" class="form-label">
                    <h5>Comment from <?php echo e($opportunity->customer_name); ?></h5>
                </label>
                <textarea class="form-control" id="description" name="description" rows="3"
                    readonly> <?php echo e($opportunity->comment); ?></textarea>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function updateStatus(selected, id) {
            if (selected == "ongoing") {
                window.location.href = "/opportunity/status/" + id;
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\MT\resources\views/Admin/viewOpportunity.blade.php ENDPATH**/ ?>