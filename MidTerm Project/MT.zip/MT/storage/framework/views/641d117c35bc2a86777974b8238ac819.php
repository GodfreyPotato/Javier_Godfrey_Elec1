
<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <h2 class="mb-4 text-center">Users</h2>

        <div class="d-flex flex-column">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="justify-content-center align-items-center d-flex rounded shadow p-2 my-2">
                    <div class=" w-75">
                        <h5 class="mb-1"><?php echo e($user->name); ?></h5>
                        <div><span>
                                Email: <?php echo e($user->email); ?>

                            </span></div>
                        <div> <span>
                                Role: <?php echo e($user->role); ?>

                            </span></div>
                        <div> <span>
                                Address: <?php echo e($user->address); ?>

                            </span></div>
                    </div>
                    <div class="justify-content-center d-flex w-25"><a href="<?php echo e(route('user.show', ['user' => $user])); ?>"><img
                                src="/images/file.png" width="18" alt=""></a></div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <!-- Optional pagination -->
        <div class="mt-4 d-flex justify-content-center">
            <?php echo e($users->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\MT\resources\views/Admin/viewUsers.blade.php ENDPATH**/ ?>