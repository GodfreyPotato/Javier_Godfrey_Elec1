
<?php $__env->startSection('content'); ?>

    <div class="p-5 d-flex flex-column justify-content-center align-items-center">

        <h3>Reports From Customers</h3>

        <table class="table table-striped table-hover align-middle text-center w-75 ">
            <thead class="table-danger">
                <tr>
                    <th>#</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Staff Name</th>
                    <th scope="col">Reason</th>
                    <th scope="col">Comment</th>
                    <th scope="col">Deal</th>
                    <th scope="col">Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $num = 1;
                ?>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $numShow = $num + (($reports->currentPage() - 1) * 10);
                    ?>
                    <tr>
                        <td><?php echo e($numShow); ?></td>
                        <td><?php echo e($report->customer_name); ?></td>
                        <td><?php echo e($report->staff_name); ?></td>
                        <td>
                            <?php echo e(strtoupper($report->reason)); ?>

                        </td>
                        <td style="max-width: 200px;"><?php echo e($report->comment); ?></td>
                        <td><?php echo e($report->title); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($report->date)->format('M d, Y \a\t g:i A')); ?></td>
                    </tr>
                    <?php
                        $num += 1;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <div class="d-flex justify-content-center mt-4"><?php echo e($reports->links()); ?> </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\MT\resources\views/Admin/viewReports.blade.php ENDPATH**/ ?>