

<?php $__env->startSection('content'); ?>

    <div class="bg-white w-100  d-flex" style="height: 80%;">

        <div class="w-75 d-flex flex-column align-items-center px-5 container h-100">
            <div class="w-100 d-flex align-items-center my-4">

                <select name="" id="reload" class="form-control text-center mr-3" style="width:20%;">
                    <option value="Opportunity" <?php echo e($selected == "Opportunity" ? "selected" : ""); ?>>Opportunity</option>
                    <option value="Deal" <?php echo e($selected == "Deal" ? "selected" : ""); ?>>Deals</option>
                </select>

                <?php if(session('success')): ?>
                    <span class="text-success"><?php echo e(session('success')); ?></span>
                <?php else: ?> <?php if(session('delete')): ?>
                        <span class="text-success"><?php echo e(session('delete')); ?></span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class=" w-100 d-flex flex-column align-items-center h-75">
                <?php if($selected == "Opportunity"): ?>
                    <?php $__currentLoopData = $home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opportunity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-100 rounded shadow-sm bg-white d-flex justify-content-between p-2 align-items-center mb-2">
                            <div>

                                <span style="font-size: 18px; font-weight: bold;"><a
                                        href="<?php echo e(route('opportunity.show', ['opportunity' => $opportunity])); ?>"><?php echo e($opportunity->title); ?></a></span>

                                <div style="font-size: 14px;"><?php echo e($opportunity->name); ?></div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center" style="width:40%;">
                                <div>
                                    <div><span style="font-size: 16px; font-weight: bold;">Added on</span></div>
                                    <div><span style="font-size: 14px;">
                                            <?php echo e($opportunity->created_at->format('M d, Y \a\t g:i A')); ?></span>
                                    </div>
                                </div>
                                <div><select name="status" style="font-size: 14px;"
                                        onchange="updateStatus(this,<?php echo e($opportunity->id); ?>)" class="form-control">

                                        <option value="pending" <?php echo e($opportunity->status == "pending" ? "selected" : ""); ?>>Pending
                                        </option>
                                        <option value="ongoing">Deal</option>
                                    </select></div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = $home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="w-100 rounded p-2 shadow-sm bg-white d-flex justify-content-between p-2 align-items-center mb-2">
                            <div>
                                <div>
                                    <span style="font-size: 18px; font-weight: bold;"><?php echo e(strtoupper($deal->title)); ?>

                                        <?php echo e($deal->id); ?></span>
                                </div>
                                <div style="font-size: 14px;"><?php echo e($deal->description); ?></div>
                            </div>
                            <div class="d-flex justify-content-around align-items-center" style="width:60%;">

                                <div style="flex:1; " class="mr-3">
                                    <div><span style="font-size: 16px; font-weight: bold;">Deal Started</span></div>
                                    <div><span style="font-size: 12px;"> <?php echo e($deal->created_at->format('M d, Y \a\t g:i A')); ?></span>
                                    </div>
                                </div>
                                <div style="flex:1;">
                                    <div><span style="font-size: 16px; font-weight: bold;">Amount</span></div>
                                    <div><span style="font-size: 14px;"> ₱<?php echo e($deal->amount); ?></span></div>
                                </div>
                                <?php if($deal->remark == "ongoing"): ?>
                                    <div class="mr-3">
                                        <select name="status" style="font-size: 14px;" onchange="updateStatusDeal(this,<?php echo e($deal->id); ?>)"
                                            class="form-control">
                                            <option value="ongoing" <?php echo e($deal->remark == "ongoing" ? "selected" : ""); ?>>On Going
                                            </option>
                                            <option value="done">Done</option>
                                        </select>
                                    </div>
                                    <div style="flex:1;"> <a href="" onclick="confirmCancel2(<?php echo e($deal->id); ?>)"
                                            class="btn btn-danger btn-md" style="font-size: 14px;">Cancel</a></div>
                                <?php else: ?>
                                    <div><?php echo e($deal->remark); ?></div>
                                <?php endif; ?>



                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="d-flex justify-content-around w-100 mt-3">
                    <?php echo e($home->links()); ?>

                </div>
            </div>
        </div>
        <div class="w-25 h-100 rounded shadow">

            <div class=" container bg-white d-flex flex-column" style="height: 80%;">
                <div class="text-start my-2 ">
                    <h4>Deal History</h4>
                </div>
                <div class="w-100 shadow-sm " style="overflow-y: auto; height: 90%; max-height:90%;">
                    <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="rounded  d-flex justify-content-between p-2 align-items-center mb-2 rounded shadow-sm <?php echo e($deal->remark != 'done' ? $deal->remark == 'good' ? 'bg-success' : 'bg-danger' : 'bg-white'); ?> ">
                            <span style="font-size: 17px; font-weight:bold; "><?php echo e($deal->title); ?></span>
                            <div> <span><?php echo e($deal->updated_at->format('M d, Y \a\t g:i A')); ?></span>
                                <?php if($deal->comment != null && ($deal->remark == 'good' || $deal->remark == 'bad')): ?>
                                    <a href="<?php echo e(route('deal.show', ['deal' => $deal])); ?>"> <img src="/images/comment.png" width="17"
                                            alt=""></a>
                                <?php endif; ?>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <div class="container d-flex align-items-center justify-content-center" style="height: 15%;"><a
                    href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Log Out</a></div>
        </div>
    </div>

    <script>
        document.getElementById('reload').addEventListener("change", function () {
            var val = this.value; // Get selected value

            // Redirect dynamically based on the selected option
            if (val === "Opportunity") {
                window.location.href = "/staff/Opportunity";
            } else if (val === "Deal") {
                window.location.href = "/staff/Deal";
            }
        });

        //opportunity
        function confirmDelete(id) {
            if (confirm("Are you sure you want to delete it?")) {

                window.location.href = "/Opportunity/deleteOpportunity/" + id;
            }
        }

        function updateStatus(selected, id) {
            if (selected.value == "ongoing") {
                window.location.href = "/opportunity/status/" + id;
            }
        }

        function updateStatusDeal(selected, id) {
            if (selected.value == "done") {
                window.location.href = "/deal/status/" + id;
            }
        }

        //deal
        function confirmCancel2(id) {
            if (confirm("Are you sure you want to cancel it?")) {
                window.location.href = "/deal/cancel/" + id;
            }
        }


    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('name'); ?>
    <div> Welcome <?php echo e(Auth::user()->name); ?>! <span class="p-1 bg-success rounded">Staff</span></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Staff.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\MT\resources\views/staff/home.blade.php ENDPATH**/ ?>