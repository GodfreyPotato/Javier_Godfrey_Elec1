

<?php $__env->startSection('content'); ?>

    <div class="bg-white w-100  d-flex" style="height: 80%;">

        <div class="w-75 d-flex flex-column align-items-center px-5 container h-100">
            <div class="w-100 d-flex align-items-center my-4">

                <h2>Accepted Opportunities</h2>
                <?php if(session('success')): ?>
                    <span class="text-success"><?php echo e(session('success')); ?></span>
                <?php else: ?> <?php if(session('delete')): ?>
                    <span class="text-success"><?php echo e(session('delete')); ?></span>
                <?php endif; ?>
                <?php endif; ?>
            </div>
            <div class=" w-100 d-flex flex-column align-items-center h-75">
                <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-100 rounded shadow-sm bg-white d-flex justify-content-between p-2 align-items-center mb-2">
                        <div>

                            <span style="font-size: 18px; font-weight: bold;"><a
                                    href="<?php echo e(route('clientHome', ['id' => $deal->id])); ?>"><?php echo e($deal->title); ?></a></span>

                            <div style="font-size: 14px;"><?php echo e($deal->name); ?></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center" style="width:40%;">
                            <div>
                                <div><span style="font-size: 16px; font-weight: bold;">Amount</span></div>
                                <div><span style="font-size: 14px;"> ₱<?php echo e($deal->amount); ?></span></div>
                            </div>

                            <div><a href="" onclick="confirmDelete(<?php echo e($deal->op_id); ?>)" class="btn btn-danger btn-md"
                                    style="font-size: 14px;">Delete</a></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-around w-100 mt-3">
                    
                </div>
            </div>
        </div>
        <div class="w-25 h-100 rounded shadow">

            <div class=" container bg-white d-flex flex-column" style="height: 80%;">
                <div class="text-start my-2 ">
                    <h4>Customers</h4>
                </div>
                <div class="w-100 shadow-sm " style="overflow-y: auto; height: 90%; max-height:90%;">
                    

                </div>
            </div>
            <div class="container d-flex align-items-center justify-content-center" style="height: 15%;"><a
                    href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Log Out</a></div>
        </div>
    </div>

    <script>
        document.getElementById('reload').addEventListener("change", function () {
            var val = this.value; // Get selected value

            // Redirect dynamically based on the selected option
            if (val === "Opportunity") {
                window.location.href = "/home/Opportunity";
            } else if (val === "Deal") {
                window.location.href = "/home/Deal";
            }
        });

        //opportunity
        function confirmDelete(id) {
            if (confirm("Are you sure you want to delete it?")) {

                window.location.href = "/Opportunity/deleteOpportunity/" + id;
            }
        }

        function updateStatus(selected, id) {
            if (selected.value == "deal") {
                window.location.href = "/Opportunity/UpdateOpportunityStatus/" + id + "/" + selected.value;
            } else if (selected.value == "open") {
                window.location.href = "/Opportunity/UpdateOpportunityStatus/" + id + "/" + selected.value;
            }
        }

        //deal
        function confirmDelete2(id) {
            if (confirm("Are you sure you want to delete it?")) {

                window.location.href = "/Deal/DeleteDeal/" + id;
            }
        }

        function updateStatus2(selected, id) {
            window.location.href = "/Deal/UpdateDealStatus/" + id + "/" + selected.value;

        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Customer.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\CRMSourceCode(Admin-Client)\resources\views/Customer/home.blade.php ENDPATH**/ ?>