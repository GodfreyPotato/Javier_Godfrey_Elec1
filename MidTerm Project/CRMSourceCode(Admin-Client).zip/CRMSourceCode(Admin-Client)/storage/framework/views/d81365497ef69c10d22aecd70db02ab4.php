<?php $__env->startSection('content'); ?>
    <div class="h-100">
        <form action="<?php echo e(route('processInteraction')); ?>" method="POST" class="h-100 bg-primary d-flex">
            <?php echo csrf_field(); ?>

            <div class="w-75 bg-white h-100 container d-flex flex-column justify-content-around">
                <?php if(session('success')): ?>
                    <span class="text-success"><?php echo e(session('success')); ?></span>
                <?php else: ?>
                    <span class="text-danger"><?php echo e(session('error')); ?></span>
                <?php endif; ?>
                <div class=" ">
                    <label for="">
                        <h5>Title</h5>
                    </label> <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" name="title" class="form-control rounded shadow">
                </div>

                <div class="h-75 ">
                    <label for="">
                        <h5>Description</h5>
                    </label> <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <textarea name="description" id="" class="form-control rounded shadow"
                        style="height: 80%; width: 100%; resize: none;"></textarea>
                </div>
            </div>

            <div class="w-25 bg-secondary h-100 d-flex flex-column justify-content-around container">
                <div class="form-floating"><label for="customer">Customer</label>
                    <select name="customer_id" class="form-control" id="customer">
                        <?php if(isset($selected) && count($selected) > 0): ?>
                            <option value="<?php echo e($selected[0]->id); ?>" selected><?php echo e($selected[0]->name); ?></option>
                        <?php else: ?>
                            <option value="" selected disabled>Select a Customer</option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-floating"><label for="it">Interaction Type</label>
                    <select name="interaction_type" class="form-control" id="it">
                        <option value="" selected disabled>Select Interaction Type</option>
                        <option value="email">Email</option>
                        <option value="call">Call</option>
                        <option value="meeting">Meeting</option>
                        <option value="chat">Chat</option>
                    </select>
                    <?php $__errorArgs = ['interaction_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-floating"> <label for="ea">Estimated Amount</label>
                    <input type="number" name="estimated_value" id="ea" class="form-control" placeholder="">
                    <?php $__errorArgs = ['estimated_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="btn btn-primary btn-md" type="submit">Save</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\CRMSourceCode(Admin-Client)\resources\views/Create/Interaction.blade.php ENDPATH**/ ?>