<?php $__env->startSection('content'); ?>
    <div class="h-100 d-flex flex-column align-items-center justify-content-center ">
        <div class="w-50 p-2 rounded shadow-lg p-3">
            <?php if(session('success')): ?>
                <span class="text-success"><?php echo e(session('success')); ?></span>
            <?php elseif(session('error')): ?>
                <span class="text-danger"><?php echo e(session('error')); ?></span>
            <?php endif; ?>
            <div class="bg-primary rounded">
                <h2 class="text-center text-white">Add New Customer</h2>
            </div>
            <div class="bg-white">
                <form action="<?php echo e(route('processCustomer')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-group">
                        <label class="input-group-text w-25 mr-2 mb-2" for="">Name</label>
                        <input type="text " class="form-control" name="name" id="" placeholder="Juan Dela Pena">

                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-group">
                        <label class="input-group-text w-25 mr-2 mb-2" for="">Email</label>
                        <input type="text " class="form-control" name="email" id="" placeholder="nasus@gmail.com">
                    </div>
                    <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-group">
                        <label class="input-group-text w-25 mr-2 mb-2" for="">Birthdate</label>
                        <input type="date" class="form-control" name="birthdate" id="">
                    </div>
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="input-group">
                        <label class="input-group-text w-25 mr-2 mb-2" for="">Address</label>
                        <input type="text " class="form-control" name="address" id="" placeholder="#1 San Vicente, Canada">
                    </div>
                    <div class="d-flex justify-content-center align-items-center">
                        <button type="submit" class="btn btn-success">Add Customer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\customerRelationshipManagementSourceCode\resources\views/Create/Customer.blade.php ENDPATH**/ ?>