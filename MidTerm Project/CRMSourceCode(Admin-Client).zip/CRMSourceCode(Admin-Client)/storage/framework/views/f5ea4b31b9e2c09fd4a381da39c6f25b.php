<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        #result {
            position: absolute;
            width: 100%;
            background: rgb(240, 239, 239);
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</head>

<body class="d-flex flex-column vh-100">

    <div class="bg-dark d-flex justify-content-between align-items-center p-3" style="height:20%; font-size: 20px;">
        <div class="w-50">
            <div class="mb-2">
                <a href="<?php echo e(route('home')); ?>" style="text-decoration: none; color: white;">
                    <h3>We DIY</h3>
                </a>
            </div>
            <nav class="d-flex w-100">
                <a href="<?php echo e(route('home')); ?>" class="text-white mr-5" style="font-size: 18px; ">Home</a>
                <a href="<?php echo e(route('showActivities')); ?>" class="text-white mr-5" style="font-size: 18px;">Activities</a>
                <a href="<?php echo e(route('createCustomer')); ?>" class="text-white mr-5" style="font-size: 18px;">Add Customer</a>
                <a href="<?php echo e(route('createInteraction')); ?>" class="text-white mr-5" style="font-size: 18px;">Create
                    Interaction</a>
            </nav>

        </div>
        <div class="d-flex justify-content-between w-25">
            <?php echo $__env->yieldContent('upper-right'); ?>
            <div class=" w-75" style="position: relative;">
                <input id="search" type="text" class="form-control" placeholder="Search opportunity">
                <ul id="result">

                </ul>
            </div>
        </div>

    </div>

    <?php echo $__env->yieldContent('content'); ?>
    <script>
        $(document).ready(function () {
            $('#search').on('keyup', function () {
                let word = $(this).val();
                if (word.length > 0) {
                    $.ajax({
                        url: "/search/" + encodeURIComponent(word),
                        type: "GET",
                        data: { word: word },
                        success: function (data) {
                            $("#result").html(data);
                        }
                    });
                } else {
                    $("#result").html("");
                }
            });


        });



    </script>
</body>

</html><?php /**PATH C:\Users\Godfrey Javier\Downloads\Websys activities\MidTerm Project\CRMSourceCode(Admin-Client)\resources\views/master.blade.php ENDPATH**/ ?>